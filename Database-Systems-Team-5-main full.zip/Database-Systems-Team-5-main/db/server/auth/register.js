//POST /api/auth/register  body: { firstName, lastName, email, password }
//Creates a customer account and signs the customer in. Employees are not created here,
//They are added by the manager or by a seed script.
const { route, readBody, HttpError } = require('../../lib/http');
const { query } = require('../../lib/db');
const { hashPassword, setAuthCookie } = require('../../lib/auth');
const validate = require('../../lib/validate');

//2627 / 2601 = unique index violation. The email is unique even for accounts
//that were marked for deletion (closed accounts), so those addresses stay taken.
const DUPLICATE = [2627, 2601];

module.exports = route({
    POST: async (req, res) => {
        const body = readBody(req);
        const firstName = validate.text(body.firstName, 'First name', { max: 50 });
        const lastName = validate.text(body.lastName, 'Last name', { max: 50 })
        const email = validate.email(body.email);
        const password = validate.newPassword(body.password);

        const passwordHash = await hashPassword(password);

        let id;
        try {
            const r = await query(
                `INSERT INTO CUSTOMER (First_name, Last_name, Email, Password_hash)
                 OUTPUT INSERTED.Customer_id as id
                 VALUES (@firstName, @lastName, @email, @passwordHash)`,
               { firstName, lastName, email, passwordHash });
            id = r.recordset[0].id;
        }
        catch (err) {
            if (DUPLICATE.includes(err.number)) {
                const closed = await query('SELECT Customer_id FROM CUSTOMER WHERE Email = @email AND Marked_for_deletion = 1', { email });
                if (closed.recordset.length > 0) {
                    throw new HttpError(409, 'This email belongs to a closed account. Please use a different email address.', 'ACCOUNT_CLOSED');
                }
                throw new HttpError(409, 'An account with this email already exists.', 'EMAIL_TAKEN');
            }
            throw err;
        }

        const user = { id, name: firstName, role: 'customer' };
        setAuthCookie(res, user);
        return { status: 201, body: { user } };
    },
});